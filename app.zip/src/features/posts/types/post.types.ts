export type MediaType = "IMAGE" | "VIDEO" | "TEXT";

export type Post = {
  id: string;
  astrologerId: string;
  content: string;
  mediaUrl: string | null;
  mediaType: MediaType;
  linkedServiceId: string | null;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  // Joined fields (baad mein)
  astrologerName?: string;
  astrologerAvatar?: string;
};

export type CreatePostPayload = {
  content: string;
  mediaUrl?: string;
  mediaType?: MediaType;
  linkedServiceId?: string;
  tags?: string[];
};

export type ImageKitAuthToken = {
  token: string;
  expire: number;
  signature: string;
};
