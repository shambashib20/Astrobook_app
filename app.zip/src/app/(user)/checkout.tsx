import Header from "@/components/header";
import { useAstrologerProfile } from "@/features/astrologer/hooks/useAstrologerProfile";
import { consultationService } from "@/features/consultation/service";
import { useUser } from "@/features/auth/store/auth.store";
import { Feather } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

export default function CheckoutScreen() {
  const router = useRouter();
  const user = useUser();
  const { astroId, serviceId, scheduledAt } = useLocalSearchParams<{
    astroId: string;
    serviceId: string;
    scheduledAt: string;
  }>();

  const {
    astrologer,
    services,
    loading: profileLoading,
  } = useAstrologerProfile(astroId);
  const service = services.find((s) => s.id === serviceId) ?? null;

  const [placing, setPlacing] = useState(false);

  const scheduledDate = scheduledAt ? new Date(scheduledAt) : null;

  const handlePayment = async () => {
    if (!astroId || !serviceId || !scheduledAt) return;
    setPlacing(true);
    try {
      const appointment = await consultationService.initiateBooking({
        astrologerId: astroId,
        serviceId,
        scheduledAt,
      });

      // NOTE: Real payment gateway (Razorpay) abhi integrate nahi hai —
      // booking "pending" status mein save ho gayi hai. Payment step
      // add hote hi yahan create-order + verify flow lagega.
      Alert.alert(
        "Payment Coming Soon",
        "Online payment abhi available nahi hai. Tumhari booking 'pending' status mein save ho gayi hai — astrologer confirm karega.",
        [
          {
            text: "OK",
            onPress: () =>
              router.replace({
                pathname: "/(user)/booking-confirmation" as any,
                params: { appointmentId: appointment.id },
              }),
          },
        ],
      );
    } catch (err: any) {
      Alert.alert(
        "Error",
        err?.response?.data?.message || "Booking create nahi ho payi",
      );
    } finally {
      setPlacing(false);
    }
  };

  if (profileLoading || !astrologer || !service || !scheduledDate) {
    return (
      <View style={[styles.root, styles.centerFill]}>
        <ActivityIndicator color="#9d0399" size="large" />
      </View>
    );
  }

  return (
    <View style={styles.root}>
      <Header />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
      >
        {/* --- ORDER SUMMARY CARD --- */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Order Summary</Text>

          <View style={styles.orderRow}>
            <View style={styles.orderEmoji}>
              <Text style={{ fontSize: 28 }}>
                {astrologer.meta?.emoji ?? "🔮"}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.orderServiceName}>{service.title}</Text>
              <Text style={styles.orderAstroName}>with {astrologer.name}</Text>
              <View style={styles.orderChipsRow}>
                <View style={styles.chip}>
                  <Text style={styles.chipText}>
                    ⏱ {service.durationMinutes} min
                  </Text>
                </View>
              </View>
              <View style={styles.slotRow}>
                <Feather name="calendar" size={12} color="#9d0399" />
                <Text style={styles.slotText}>
                  {scheduledDate.toLocaleDateString("en-IN", {
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                  })}{" "}
                  •{" "}
                  {scheduledDate.toLocaleTimeString("en-IN", {
                    hour: "2-digit",
                    minute: "2-digit",
                    hour12: true,
                  })}
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* --- CUSTOMER DETAILS CARD --- */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Customer details</Text>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Name : </Text>
            <Text style={styles.detailValue}>{user?.name ?? "—"}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Phone : </Text>
            <Text style={styles.detailValue}>{user?.phone ?? "—"}</Text>
          </View>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Email : </Text>
            <Text style={styles.detailValue}>{user?.email ?? "—"}</Text>
          </View>
        </View>

        {/* --- PRICE DETAILS CARD --- */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Price details</Text>

          <View style={styles.priceRow}>
            <Text style={styles.totalLabel}>Total Amount</Text>
            <Text style={styles.totalValue}>₹ {service.price ?? "—"}</Text>
          </View>
        </View>

        {/* --- CANCELLATION POLICY --- */}
        <View style={styles.policyCard}>
          <View style={styles.policyHeaderRow}>
            <Feather name="alert-circle" size={14} color="#F59E0B" />
            <Text style={styles.policyTitle}>Cancellation Policy</Text>
          </View>
          <Text style={styles.policyText}>
            • Booking cancel karne ke liye "My Bookings" mein jaake cancel karo.
          </Text>
        </View>

        <View style={{ height: 90 }} />
      </ScrollView>

      <View style={styles.stickyBottom}>
        <TouchableOpacity
          style={[styles.paymentBtn, placing && styles.paymentBtnDisabled]}
          onPress={handlePayment}
          disabled={placing}
        >
          {placing ? (
            <ActivityIndicator size="small" color="#FFF" />
          ) : (
            <Text style={styles.paymentBtnText}>
              Confirm Booking • ₹{service.price ?? "—"}
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#F9F5FF" },
  centerFill: { alignItems: "center", justifyContent: "center" },
  listContent: { padding: 16, gap: 14, paddingBottom: 40 },

  card: {
    backgroundColor: "#FFF",
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: "#EDE9FF",
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    gap: 8,
  },
  sectionTitle: { fontSize: 15, fontWeight: "700", color: "#1F2937" },

  orderRow: { flexDirection: "row", gap: 12, alignItems: "flex-start" },
  orderEmoji: {
    width: 52,
    height: 52,
    borderRadius: 12,
    backgroundColor: "#F3E8FF",
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  orderServiceName: {
    fontSize: 15,
    fontWeight: "700",
    color: "#1A1A2E",
    marginBottom: 2,
  },
  orderAstroName: { fontSize: 12, color: "#6B7280", marginBottom: 6 },
  orderChipsRow: { flexDirection: "row", gap: 6, marginBottom: 6 },
  chip: {
    backgroundColor: "#F5F0FF",
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  chipText: { fontSize: 11, color: "#6B21A8", fontWeight: "600" },
  slotRow: { flexDirection: "row", alignItems: "center", gap: 5 },
  slotText: { fontSize: 12, color: "#9d0399", fontWeight: "600" },

  detailRow: { flexDirection: "row", alignItems: "flex-start" },
  detailLabel: { fontSize: 13, color: "#6B7280", fontWeight: "500" },
  detailValue: { fontSize: 13, color: "#1F2937", fontWeight: "600", flex: 1 },

  priceRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 2,
  },
  totalLabel: { fontSize: 15, fontWeight: "700", color: "#1F2937" },
  totalValue: { fontSize: 17, fontWeight: "800", color: "#9d0399" },

  policyCard: {
    backgroundColor: "#FFFBEB",
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: "#FDE68A",
    gap: 5,
  },
  policyHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginBottom: 4,
  },
  policyTitle: { fontSize: 13, fontWeight: "700", color: "#92400E" },
  policyText: { fontSize: 12, color: "#78350F", lineHeight: 18 },

  stickyBottom: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: "#FFF",
    paddingHorizontal: 16,
    paddingVertical: 12,
    paddingBottom: 24,
    borderTopWidth: 1,
    borderTopColor: "#EDE9FF",
    elevation: 10,
  },
  paymentBtn: {
    backgroundColor: "#9d0399",
    borderRadius: 12,
    paddingVertical: 15,
    width: "100%",
    alignItems: "center",
    elevation: 3,
  },
  paymentBtnDisabled: { opacity: 0.6 },
  paymentBtnText: { color: "#FFF", fontSize: 16, fontWeight: "800" },
});
