import Header from "@/components/header";
import { useFeedPosts } from "@/features/posts/hooks/useFeed";
import type { Post } from "@/features/posts/types/post.types";
import MaterialCommunityIcons from "@expo/vector-icons/MaterialCommunityIcons";
import { useRouter } from "expo-router";
import { useEffect } from "react";
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const { width: SCREEN_WIDTH } = Dimensions.get("window");

const BG_PALETTE = [
  "#6B21A8",
  "#1E3A5F",
  "#92400E",
  "#065F46",
  "#9D174D",
  "#4C1D95",
];
function colorForId(id: string) {
  let hash = 0;
  for (let i = 0; i < id.length; i++) hash = (hash + id.charCodeAt(i)) % 997;
  return BG_PALETTE[hash % BG_PALETTE.length]!;
}

export default function FeedScreen() {
  const router = useRouter();
  const {
    posts,
    loading,
    refreshing,
    loadingMore,
    hasMore,
    error,
    fetchFeed,
    loadMore,
  } = useFeedPosts();

  useEffect(() => {
    fetchFeed();
  }, []);

  const goToPost = (postId: string) => {
    router.push({
      pathname: "/(user)/post/[id]" as any,
      params: { id: postId },
    });
  };

  const goToAstrologer = (astrologerId: string) => {
    router.push({
      pathname: "/(user)/astrologer-profile" as any,
      params: { id: astrologerId },
    });
  };

  const renderPost = ({ item: post }: { item: Post }) => {
    const bgColor = colorForId(post.astrologerId);
    return (
      <View style={styles.postCard}>
        {/* Post Header */}
        <TouchableOpacity
          style={styles.postHeader}
          activeOpacity={0.8}
          onPress={() => goToAstrologer(post.astrologerId)}
        >
          <View style={styles.postAuthorRow}>
            <View style={[styles.postAvatar, { backgroundColor: bgColor }]}>
              <Text style={styles.postAvatarEmoji}>
                {post.astrologerAvatar ?? "🔮"}
              </Text>
            </View>
            <View>
              <Text style={styles.postAuthorName}>
                {post.astrologerName ?? "Astrologer"}
              </Text>
              <Text style={styles.postTime}>
                {new Date(post.createdAt).toLocaleDateString("en-IN", {
                  day: "2-digit",
                  month: "short",
                  year: "numeric",
                })}
              </Text>
            </View>
          </View>
          <TouchableOpacity
            style={styles.followBtn}
            onPress={(e) => e.stopPropagation?.()}
          >
            <Text style={styles.followBtnText}>Follow +</Text>
          </TouchableOpacity>
        </TouchableOpacity>

        {/* Post Content */}
        <TouchableOpacity
          activeOpacity={0.95}
          onPress={() => goToPost(post.id)}
        >
          {post.mediaType === "IMAGE" && post.mediaUrl ? (
            <Image
              source={{ uri: post.mediaUrl }}
              style={styles.postImage}
              resizeMode="cover"
            />
          ) : (
            <View style={[styles.postImageArea, { backgroundColor: bgColor }]}>
              <Text style={styles.postContent}>{post.content}</Text>
              <View style={styles.postFooterRow}>
                <View style={styles.postLogoSmall}>
                  <Text style={styles.postLogoAstro}>Astro</Text>
                  <View style={styles.postLogoBadge}>
                    <Text style={styles.postLogoBook}>Book</Text>
                  </View>
                </View>
              </View>
            </View>
          )}
          {post.mediaType === "IMAGE" && (
            <Text style={styles.imagePostCaption} numberOfLines={2}>
              {post.content}
            </Text>
          )}
        </TouchableOpacity>

        {/* Post Bottom */}
        <View style={styles.postBottom}>
          <View style={styles.actionsRow}>
            <TouchableOpacity
              style={styles.actionBtn}
              onPress={() => goToPost(post.id)}
            >
              <MaterialCommunityIcons
                name="comment-outline"
                size={22}
                color="#9d0399"
              />
              <Text style={styles.count}>View</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.bookBtn}
              onPress={() => goToAstrologer(post.astrologerId)}
            >
              <Text style={styles.bookText}>Book Now</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.root}>
      <Header />

      {loading ? (
        <View style={styles.centerFill}>
          <ActivityIndicator color="#9d0399" size="large" />
        </View>
      ) : error ? (
        <View style={styles.centerFill}>
          <Text style={styles.emptyText}>{error}</Text>
        </View>
      ) : posts.length === 0 ? (
        <View style={styles.centerFill}>
          <Text style={styles.emptyText}>Abhi tak koi post nahi hai</Text>
        </View>
      ) : (
        <FlatList
          data={posts}
          keyExtractor={(item) => item.id}
          renderItem={renderPost}
          refreshing={refreshing}
          onRefresh={() => fetchFeed(true)}
          onEndReached={loadMore}
          onEndReachedThreshold={0.4}
          showsVerticalScrollIndicator={false}
          ListFooterComponent={
            loadingMore ? (
              <ActivityIndicator
                color="#9d0399"
                style={{ marginVertical: 20 }}
              />
            ) : !hasMore && posts.length > 0 ? (
              <Text style={styles.endOfFeedText}>
                Bas itna hi — aur posts nahi hain
              </Text>
            ) : null
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: "#fff" },
  centerFill: { flex: 1, alignItems: "center", justifyContent: "center" },
  emptyText: { fontSize: 14, color: "#9CA3AF" },
  endOfFeedText: {
    textAlign: "center",
    fontSize: 12,
    color: "#9CA3AF",
    paddingVertical: 24,
  },

  postCard: { backgroundColor: "#FFF", marginTop: 0 },
  postHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  postAuthorRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  postAvatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    alignItems: "center",
    justifyContent: "center",
  },
  postAvatarEmoji: { fontSize: 20 },
  postAuthorName: { fontSize: 15, fontWeight: "700", color: "#0b1d5b" },
  postTime: { fontSize: 11, color: "#999" },
  followBtnText: { color: "#9d0399", fontSize: 12, fontWeight: "600" },
  followBtn: {},
  postImageArea: {
    width: SCREEN_WIDTH,
    minHeight: 320,
    padding: 24,
    justifyContent: "space-between",
  },
  postImage: { width: SCREEN_WIDTH, height: 320 },
  imagePostCaption: {
    fontSize: 14,
    color: "#374151",
    paddingHorizontal: 14,
    paddingTop: 8,
  },
  postContent: {
    color: "#FFF",
    fontSize: 16,
    lineHeight: 26,
    fontWeight: "500",
    flex: 1,
    textAlign: "center",
    marginTop: 16,
  },
  postFooterRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 20,
  },
  postLogoSmall: { flexDirection: "row", alignItems: "center" },
  postLogoAstro: { fontSize: 13, fontWeight: "800", color: "#FFF" },
  postLogoBadge: {
    backgroundColor: "#FFFFFF30",
    borderRadius: 3,
    paddingHorizontal: 5,
    paddingVertical: 1,
    marginLeft: 2,
  },
  postLogoBook: { fontSize: 13, fontWeight: "800", color: "#FFF" },
  postBottom: { paddingHorizontal: 14, paddingVertical: 10 },
  actionsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 6,
  },
  actionBtn: { flexDirection: "row", alignItems: "center", gap: 6 },
  count: { fontSize: 13, color: "#9d0399" },
  bookBtn: {
    backgroundColor: "#9d0399",
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 6,
  },
  bookText: { color: "#fff", fontSize: 12, fontWeight: "600" },
});
